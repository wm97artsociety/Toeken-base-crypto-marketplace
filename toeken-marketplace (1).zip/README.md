# TOEKEN Marketplace

A decentralized crypto marketplace on Base Mainnet using TOEKEN as the sole currency, integrated with a secure HTTPS browser extension, NFT APIs, and a dynamic encryption engine.